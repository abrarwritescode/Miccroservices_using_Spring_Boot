package com.example.employeeservice.service;

public class ProductService {
}
